package com.example.aplikasitodo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {

    WebView webHtmlCssJs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webHtmlCssJs = (WebView) findViewById(R.id.webView);

        WebSettings ws = webHtmlCssJs.getSettings();
        ws.setJavaScriptEnabled(true);
        webHtmlCssJs.loadUrl("file:///android_asset/myHTML.html");

    }
}